<?php

namespace myapp\classes;

class POSTHandler extends RESTHandler
{
	public function  process() {
	}

	public function  getOutput(){
	}

}