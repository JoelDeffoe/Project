<?php
abstract class RESTHandler
{
  final public static handleRequest()
  {

  }
  abstract public process()
  {

  }

  abstract public getOutput()
  {

  }
}
 ?>
