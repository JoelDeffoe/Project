<?php

class GETHandler extends RESTHandler
{

   final public static handleRequest()
  {

  }
  abstract public process()
  {

  }
  abstract public getOutput()
  {

  }

}
 ?>
