<?php

class ClassName extends AnotherClass
{

  
  final public static handleRequest()
  {
    
  }
  abstract public process()
  {

  }
  abstract public getOutput()
  {

  }
}

 ?>
