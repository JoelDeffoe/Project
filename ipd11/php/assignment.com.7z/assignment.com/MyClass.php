<?php

class MyClass {
    
}