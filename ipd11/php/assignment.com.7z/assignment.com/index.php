<?php
echo 'hello';

     $dns = 'mysql:host=localhost;port=3306;dbname=test';
     $dbuser = 'user';
     $dbpassword = 'user';
     $pdo = new PDO($dns, $dbuser, $dbpassword); 

     $statement = 'SELECT * FROM Test.subscribers';
     $stm = $pdo->prepare($statement);
     $stm->execute();
     $record = $stm->fetchAll(\PDO::FETCH_ASSOC);
	 echo '<pre>';
     print_r($record);
      echo '<pre>';
      
