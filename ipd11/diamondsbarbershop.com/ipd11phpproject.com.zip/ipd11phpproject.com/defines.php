<?php

define('ROOT', __DIR__);
define('INCLUDES_DIR', ROOT.'/includes');
define('CONTENT_DIR', INCLUDES_DIR.'/content');
define('LIB_DIR', ROOT.'/Lib');
define('PROJECT_APP_DIR', ROOT.'/ProjectApp');
define('VENDOR_DIR', ROOT.'/Vendor');

include ROOT . '/autoload.php';