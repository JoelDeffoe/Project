<?php

namespace myapp\classes;

class GETHandler  extends RESTHandler {
	
	public function  process() {
	}

	public function  getOutput(){
	}
	
}