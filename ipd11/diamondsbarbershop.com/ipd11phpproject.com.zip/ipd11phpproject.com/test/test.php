<?php

echo 'test<br>';