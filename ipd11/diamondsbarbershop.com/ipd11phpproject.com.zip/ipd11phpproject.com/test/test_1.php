<?php

die('test 1<br>');