<html>
    <head>
        <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" href="/assets/css/style.css" />
        <title>Test</title>
    </head>
    <body>
        <div class="container">
            Test
        </div>
        <script src="/assets/bootstrap/js/jquery-v3.2.1.min.js"></script>
        <script src="/assets/bootstrap/js/popper.min.js"></script>
        <script src="/assets/bootstrap/js/bootstrap-v4.0.0-beta.3.min.js"></script>
        <script src="/assets/js/script.js"></script>
    </body>
</html>