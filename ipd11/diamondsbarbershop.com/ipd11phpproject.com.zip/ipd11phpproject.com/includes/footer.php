<footer class="footer">
    <p>&copy; Company <?php echo date('Y'); ?></p>
</footer>